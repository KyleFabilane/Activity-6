﻿Imports MySql.Data.MySqlClient

Public Class LogIn_Database

    Dim connection As New MySqlConnection("datasource=localhost;port=3306;username=root;password=;database=_s_t_d")
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged

        If TextBoxPassword.UseSystemPasswordChar = True Then

            ' hide password
            TextBoxPassword.UseSystemPasswordChar = False

        Else

            ' Show password
            TextBoxPassword.UseSystemPasswordChar = True

        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Me.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim command As New MySqlCommand("SELECT `Id`, `pass` FROM `user` WHERE `Id` = @username AND `pass` = @password", connection)

        command.Parameters.Add("@username", MySqlDbType.VarChar).Value = TextBoxUsername.Text
        command.Parameters.Add("@password", MySqlDbType.VarChar).Value = TextBoxUsername.Text

        Dim adapter As New MySqlDataAdapter(command)
        Dim table As New DataTable()

        adapter.Fill(table)

        If table.Rows.Count = 0 Then

            Dim unused1 = MessageBox.Show("Invalid Username Or Password")

        Else

            Dim unused = MessageBox.Show("Logged In")

        End If
    End Sub
End Class
