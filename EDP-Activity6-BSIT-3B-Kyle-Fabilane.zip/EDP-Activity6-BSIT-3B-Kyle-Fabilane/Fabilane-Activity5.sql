use kiel1;

LOAD DATA INFILE
'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/UploadEmployeeData.csv'
INTO TABLE employee
	fields terminated by ',' lines terminated by '\r\n' 
    ignore 1 lines;
    
SELECT * FROM kiel1.employee;

SELECT * into outfile
'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/UploadEmployeeData.txt'
	 fields terminated by '\t'lines terminated by '\r\n'
     from employee